开源的像素衬线字体，遵循SIL开源字体协议。 

目前支持拉丁语-1增补，拉丁语扩充-A，部分希腊语和科普特语以及部分西里尔文。

提供.ttf, .otf, .woff和.woff2字体格式下载。 

该字体家族包含常规和粗体两种字重，常规和斜体两种样式。

OpenType字体支持例如fi, ffi, fl, ffl等连字以及ct, st, sp的自由连字。


Open source pixel serif fonts, under SIL Open Font License.

Support Basic Latin, Latin-1 Supplement, Latin Extended-A and part of Greek and Coptic and Cyrillic.

Provide .ttf, .otf, .woff and .woff2 format downloading.

This font-family contains Regular, Bold font-weight, and Regular, Italic style.

OpenType fonts supports standard ligatures(liga) like fi, ffi, fl, ffl and discretionary liagatures(dlig) like ct, st, sp.



Name your own price
https://steven-liu.itch.io/illusionserif

Appreciate and follow:
https://www.behance.net/d42270cb